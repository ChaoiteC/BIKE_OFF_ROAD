#ifndef __LQ_FLASH_H
#define __LQ_FLASH_H


void Test_Flash(void);

#endif
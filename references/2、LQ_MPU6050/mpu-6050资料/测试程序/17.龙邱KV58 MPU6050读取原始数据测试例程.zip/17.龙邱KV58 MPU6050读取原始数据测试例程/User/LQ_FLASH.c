/*
 * Copyright (c) 2016, Freescale Semiconductor, Inc.
 * Copyright 2016-2018 NXP
 * All rights reserved.
 * 
 * SPDX-License-Identifier: BSD-3-Clause
 */

/*******************************************************************************
 * Includes
 ******************************************************************************/
#include "fsl_device_registers.h"
#include "fsl_debug_console.h"
#include "board.h"
#include "clock_config.h"
#include "fsl_flash.h"
#include "pin_mux.h"
#include "LQ_FLASH.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/

#define BUFFER_LEN 400


/*! Flash�����ṹ�� */
static flash_config_t s_flashDriver;



/*******************************************************************************
 * Code
 ******************************************************************************/


/**
  * @brief    Flash��д����
  *
  * @param    
  *
  * @return   
  *
  * @note     
  *
  * @example  
  *
  * @date     2019/5/17 ������
  */
void Test_Flash(void)
{
    
    status_t result;    /* Return code from each flash driver function */
    uint32_t destAdrss; /* Address of the target location */
    
    static uint32_t s_buffer[BUFFER_LEN];
    
    static uint32_t s_buffer_rbc[BUFFER_LEN];
    
    uint32_t pflashBlockBase = 0;
    uint32_t pflashTotalSize = 0;
    uint32_t pflashSectorSize = 0;
    
    /* ��ʼ��FLASH. */
    result = FLASH_Init(&s_flashDriver);
    if (kStatus_FTFx_Success != result)
    {
        PRINTF("\r\n\r\n\r\n\t---- HALTED DUE TO FLASH ERROR! ----");
        while (1)
        {
        }
    }
    
    /* ��ȡFLASH��Ϣ */
    FLASH_GetProperty(&s_flashDriver, kFLASH_PropertyPflash0BlockBaseAddr, &pflashBlockBase);
    FLASH_GetProperty(&s_flashDriver, kFLASH_PropertyPflash0TotalSize, &pflashTotalSize);
    FLASH_GetProperty(&s_flashDriver, kFLASH_PropertyPflash0SectorSize, &pflashSectorSize);
    

    PRINTF("\r\n PFlash Example Start \r\n");
    PRINTF("\r\n PFlash Information: ");
    PRINTF("\r\n Total Program Flash Size:\t%d KB, Hex: (0x%x)", (pflashTotalSize / 1024), pflashTotalSize);
    PRINTF("\r\n Program Flash Sector Size:\t%d KB, Hex: (0x%x) ", (pflashSectorSize / 1024), pflashSectorSize);
    
     
    
    /* �������������ַ �����ǵ�����ʮ������ */
    destAdrss = FLASH_ADDR(10, 0);
    
    /* �������� */
    result = FLASH_Erase(&s_flashDriver, destAdrss, pflashSectorSize, kFTFx_ApiEraseKey);
    if (kStatus_FTFx_Success != result)
    {
        PRINTF("\r\n\r\n\r\n\t---- HALTED DUE TO FLASH ERROR! ----");
        while (1)
        {
        }
    }
    
    
    /* Print message for user. */
    PRINTF("\r\n Successfully Erased Sector 0x%x -> 0x%x\r\n", destAdrss, (destAdrss + pflashSectorSize));
    
    /* Print message for user. */
    PRINTF("\r\n Program a buffer to a sector of flash ");
    /* Prepare user buffer. */
    for (int i = 0; i < BUFFER_LEN; i++)
    {
        s_buffer[i] = i;
    }
    
    /* д������ */
    result = FLASH_Program(&s_flashDriver, destAdrss, (uint8_t *)s_buffer, sizeof(s_buffer));
    if (kStatus_FTFx_Success != result)
    {
        PRINTF("\r\n\r\n\r\n\t---- HALTED DUE TO FLASH ERROR! ----");
        while (1)
        {
        }
    }
    
    /* �����Ƚ� */
    for (uint32_t i = 0; i < BUFFER_LEN; i++)
    {
        s_buffer_rbc[i] = FLASH_Read(10, i*4, uint32_t);
        if (s_buffer_rbc[i] != s_buffer[i])
        {
            PRINTF("\r\n\r\n\r\n\t---- HALTED DUE TO FLASH ERROR! ----");
            while (1)
            {
            }
        }
    }
    
    PRINTF("\r\n Successfully Programmed and Verified Location 0x%x -> 0x%x \r\n", destAdrss,
           (destAdrss + sizeof(s_buffer)));
    
    
    /* Print finished message. */
    PRINTF("\r\n End of PFlash Example \r\n");
    while (1)
    {
    }

}
